@echo off
title Ledger - Stop Services
echo ===================================================
echo   Stopping Backend (8000) and Frontend (5173)...
echo ===================================================

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000') do (
    taskkill /f /pid %%a >nul 2>&1
)

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5173') do (
    taskkill /f /pid %%a >nul 2>&1
)

echo.
echo All services stopped successfully.
timeout /t 2 /nobreak >nul
exit /b 0
