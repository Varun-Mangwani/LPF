import io
import re
from datetime import datetime
from dateutil import parser as date_parser
import pandas as pd
from fastapi import APIRouter, UploadFile, File, HTTPException, Query

from db import db_cursor
from models import UploadResponse
from engines.categorizer import categorize
from engines.recurring import recurring_merchant_set

router = APIRouter(prefix="/api/upload", tags=["upload"])

COLUMN_ALIASES = {
    "date": ["date", "txn_date", "transaction_date", "value_date", "posting_date", "booking_date", "trans_date", "pst_date", "dt", "timestamp"],
    "merchant": ["merchant", "merchant_name", "payee", "description", "details", "narrative", "particulars", "remarks", "party_name", "trans_details", "name"],
    "amount": ["amount", "amt", "value", "sum", "price", "net_amount", "transaction_amount"],
    "type": ["type", "transaction_type", "txn_type", "credit_debit", "cr_dr", "direction"],
    "debit": ["debit", "withdrawal", "withdrawals", "dr", "debit_amount", "withdrawal_amount", "outflow"],
    "credit": ["credit", "deposit", "deposits", "cr", "credit_amount", "deposit_amount", "inflow"],
}


def _normalize_date(val) -> str:
    if pd.isna(val) or not str(val).strip():
        return datetime.now().strftime("%Y-%m-%d")
    s = str(val).strip()

    # Attempt 1: Standard pandas parser with dayfirst=True
    try:
        dt = pd.to_datetime(s, dayfirst=True, errors="coerce")
        if not pd.isna(dt):
            return dt.strftime("%Y-%m-%d")
    except Exception:
        pass

    # Attempt 2: Standard pandas parser without dayfirst
    try:
        dt = pd.to_datetime(s, dayfirst=False, errors="coerce")
        if not pd.isna(dt):
            return dt.strftime("%Y-%m-%d")
    except Exception:
        pass

    # Attempt 3: dateutil fuzzy parser (handles '11-Sep-2026', 'SEP 11 2026', '2026.09.11', etc.)
    try:
        dt = date_parser.parse(s, fuzzy=True)
        return dt.strftime("%Y-%m-%d")
    except Exception:
        pass

    # Safe fallback if completely unparseable
    return datetime.now().strftime("%Y-%m-%d")


def _clean_amount(val) -> float:
    if pd.isna(val) or val is None:
        return 0.0
    s = str(val).strip()
    if not s:
        return 0.0
    # Remove currency codes, commas, symbols
    cleaned = re.sub(r"[^\d.-]", "", s)
    try:
        return float(cleaned) if cleaned else 0.0
    except ValueError:
        return 0.0


def _extract_merchant_from_narration(narration: str) -> str:
    if not narration or not isinstance(narration, str):
        return "Unknown Merchant"
    text = narration.strip()
    if not text:
        return "Unknown Merchant"

    patterns = [
        r"^UPI/[^/]+/([^/]+)",
        r"^UPI/([^/]+)",
        r"^(?:POS|ATM|ECOM|INF|ACH|NEFT|RTGS|IMPS)[/\s\-:]+([^/\s\-:]+(?:\s+[^/\s\-:]+){0,2})",
        r"^PAYMENT\s+TO\s+([^\s]+)",
        r"^TRANSFER\s+TO\s+([^\s]+)",
        r"^BILL\s+PAYMENT\s+([^\s]+)",
    ]
    for p in patterns:
        m = re.search(p, text, re.IGNORECASE)
        if m:
            extracted = m.group(1).strip()
            if len(extracted) >= 2:
                return extracted.title()

    cleaned = re.sub(r"\b\d{8,}\b", "", text)
    cleaned = re.sub(r"/\S+@", "", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned[:40].title() if cleaned else text[:40].title()


def _process_csv(raw: bytes, user_id: int) -> UploadResponse:
    """Core Bank Statement & CSV parse logic with fail-safe date & amount parsing."""
    try:
        # Try standard CSV read with flexible delimiter detection
        try:
            df = pd.read_csv(io.BytesIO(raw))
        except Exception:
            df = pd.read_csv(io.BytesIO(raw), sep=";", engine="python")
    except Exception as e:
        raise HTTPException(400, f"Could not parse bank statement / CSV file: {e}")

    if df.empty:
        raise HTTPException(400, "Uploaded CSV file is empty.")

    # Normalize column names using aliases
    original_cols = list(df.columns)
    col_map = {}
    for col in original_cols:
        c_clean = re.sub(r"[^\w]", "_", str(col).strip().lower()).strip("_")
        col_map[col] = c_clean

    df = df.rename(columns=col_map)
    current_cols = set(df.columns)

    renames = {}
    for target, aliases in COLUMN_ALIASES.items():
        if target not in current_cols:
            for alias in aliases:
                if alias in current_cols:
                    renames[alias] = target
                    break
    if renames:
        df = df.rename(columns=renames)

    # Detect Date column
    date_col = "date" if "date" in df.columns else None
    if not date_col:
        for c in df.columns:
            if "date" in c or "time" in c or "dt" in c:
                date_col = c
                break
    if not date_col:
        # Fallback to first column as date
        date_col = df.columns[0]

    # Detect Merchant / Narration column
    merchant_col = "merchant" if "merchant" in df.columns else None
    if not merchant_col:
        for c in df.columns:
            if any(k in c for k in ["narration", "particular", "desc", "detail", "payee", "remark", "name"]):
                merchant_col = c
                break
    if not merchant_col:
        merchant_col = df.columns[1] if len(df.columns) > 1 else df.columns[0]

    # Detect Split Debit vs Credit or Single Amount Column
    has_debit_credit = ("debit" in df.columns and "credit" in df.columns)
    amount_col = "amount" if "amount" in df.columns else None
    if not amount_col and not has_debit_credit:
        for c in df.columns:
            if any(k in c for k in ["amount", "amt", "val", "sum", "price", "bal"]):
                amount_col = c
                break
    if not amount_col and not has_debit_credit:
        amount_col = df.columns[2] if len(df.columns) > 2 else df.columns[-1]

    parsed_rows = []
    for _, r in df.iterrows():
        iso_date = _normalize_date(r.get(date_col))
        raw_merchant = str(r.get(merchant_col) or "Unknown").strip()
        merchant_name = _extract_merchant_from_narration(raw_merchant)

        if has_debit_credit:
            d_val = _clean_amount(r.get("debit"))
            c_val = _clean_amount(r.get("credit"))
            if c_val > 0:
                amt = c_val
                txn_type = "credit"
            elif d_val > 0:
                amt = d_val
                txn_type = "debit"
            else:
                raw_amt = _clean_amount(r.get(amount_col, 0)) if amount_col else 0.0
                amt = abs(raw_amt)
                txn_type = "credit" if raw_amt > 0 else "debit"
        else:
            raw_amt = _clean_amount(r.get(amount_col, 0))
            raw_type = str(r.get("type", "")).lower()
            if "cred" in raw_type or "inc" in raw_type or "cr" in raw_type or "+" in raw_type:
                txn_type = "credit"
            elif "deb" in raw_type or "exp" in raw_type or "dr" in raw_type or "-" in raw_type:
                txn_type = "debit"
            else:
                txn_type = "credit" if raw_amt > 0 else "debit"
            amt = abs(raw_amt)

        parsed_rows.append({
            "date": iso_date,
            "merchant": merchant_name,
            "amount": amt,
            "type": txn_type,
            "description": raw_merchant,
        })

    if not parsed_rows:
        raise HTTPException(400, "No valid transaction rows found in the uploaded file.")

    parsed_df = pd.DataFrame(parsed_rows)

    # --- categorize ---
    unique_merchants = parsed_df["merchant"].unique().tolist()
    cat_map = categorize(unique_merchants)
    parsed_df["category"] = parsed_df["merchant"].map(lambda m: cat_map[m]["category"])
    parsed_df["is_essential"] = parsed_df["merchant"].map(lambda m: 1 if cat_map[m]["essential"] else 0)
    parsed_df["categorized_by"] = parsed_df["merchant"].map(lambda m: cat_map[m]["source"])

    by_rule = sum(1 for v in cat_map.values() if v["source"] == "rule")
    by_llm = sum(1 for v in cat_map.values() if v["source"] == "llm")

    with db_cursor() as cur:
        cur.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if cur.fetchone() is None:
            cur.execute("INSERT INTO users (id, name) VALUES (?, ?)", (user_id, f"User {user_id}"))

        db_insert_rows = []
        for r in parsed_df.to_dict(orient="records"):
            amt = float(r["amount"])
            is_cred = (r["type"] == "credit")
            signed_amt = amt if is_cred else -amt
            if is_cred:
                t_type = "income"
            else:
                t_type = "essential" if r["is_essential"] else "discretionary"
            db_insert_rows.append((
                user_id, r["date"], r["merchant"], signed_amt, r["category"], t_type, 0
            ))

        cur.executemany(
            """INSERT INTO transactions
               (user_id, date, merchant, amount, category, type, is_recurring)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            db_insert_rows,
        )

        # Recompute recurring flags across ALL of this user's transactions.
        cur.execute("SELECT * FROM transactions WHERE user_id = ?", (user_id,))
        raw_all = [dict(r) for r in cur.fetchall()]
        all_txns = []
        for r in raw_all:
            amt = float(r["amount"])
            t_type = str(r.get("type", "")).lower()
            norm_type = "credit" if (t_type == "credit" or t_type == "income" or amt > 0) else "debit"
            date_val = r.get("date") or r.get("txn_date", "")
            all_txns.append({
                "txn_date": date_val, "merchant": r["merchant"], "amount": abs(amt), "type": norm_type
            })
        recurring_set = recurring_merchant_set(all_txns)
        cur.execute("UPDATE transactions SET is_recurring = 0 WHERE user_id = ?", (user_id,))
        if recurring_set:
            placeholders = ",".join("?" * len(recurring_set))
            cur.execute(
                f"UPDATE transactions SET is_recurring = 1 WHERE user_id = ? AND merchant IN ({placeholders})",
                (user_id, *recurring_set),
            )

    return UploadResponse(
        inserted=len(parsed_df),
        categorized_by_rule=by_rule,
        categorized_by_llm=by_llm,
        recurring_detected=len(recurring_set),
    )

    # --- categorize ---
    unique_merchants = df["merchant"].unique().tolist()
    cat_map = categorize(unique_merchants)
    df["category"] = df["merchant"].map(lambda m: cat_map[m]["category"])
    df["is_essential"] = df["merchant"].map(lambda m: 1 if cat_map[m]["essential"] else 0)
    df["categorized_by"] = df["merchant"].map(lambda m: cat_map[m]["source"])

    by_rule = sum(1 for v in cat_map.values() if v["source"] == "rule")
    by_llm = sum(1 for v in cat_map.values() if v["source"] == "llm")

    with db_cursor() as cur:
        cur.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if cur.fetchone() is None:
            cur.execute("INSERT INTO users (id, name) VALUES (?, ?)", (user_id, f"User {user_id}"))

        rows = []
        for r in df.to_dict(orient="records"):
            amt = float(r["amount"])
            is_cred = (r["type"] == "credit")
            signed_amt = amt if is_cred else -amt
            if is_cred:
                t_type = "income"
            else:
                t_type = "essential" if r["is_essential"] else "discretionary"
            rows.append((
                user_id, r["date"], r["merchant"], signed_amt, r["category"], t_type, 0
            ))

        cur.executemany(
            """INSERT INTO transactions
               (user_id, date, merchant, amount, category, type, is_recurring)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            rows,
        )

        # Recompute recurring flags across ALL of this user's transactions.
        cur.execute(
            "SELECT * FROM transactions WHERE user_id = ?",
            (user_id,),
        )
        raw_all = [dict(r) for r in cur.fetchall()]
        all_txns = []
        for r in raw_all:
            amt = float(r["amount"])
            t_type = str(r.get("type", "")).lower()
            norm_type = "credit" if (t_type == "credit" or t_type == "income" or amt > 0) else "debit"
            date_val = r.get("date") or r.get("txn_date", "")
            all_txns.append({
                "txn_date": date_val, "merchant": r["merchant"], "amount": abs(amt), "type": norm_type
            })
        recurring_set = recurring_merchant_set(all_txns)
        cur.execute("UPDATE transactions SET is_recurring = 0 WHERE user_id = ?", (user_id,))
        if recurring_set:
            placeholders = ",".join("?" * len(recurring_set))
            cur.execute(
                f"UPDATE transactions SET is_recurring = 1 WHERE user_id = ? AND merchant IN ({placeholders})",
                (user_id, *recurring_set),
            )

    return UploadResponse(
        inserted=len(df),
        categorized_by_rule=by_rule,
        categorized_by_llm=by_llm,
        recurring_detected=len(recurring_set),
    )


@router.post("", response_model=UploadResponse)
async def upload_root(user_id: int = Query(1), file: UploadFile = File(...)):
    """Primary upload endpoint used by the frontend."""
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "Please upload a .csv file")
    raw = await file.read()
    return _process_csv(raw, user_id)


@router.post("/csv", response_model=UploadResponse)
async def upload_csv(user_id: int = Query(1), file: UploadFile = File(...)):
    """Alias endpoint (explicit /csv suffix)."""
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "Please upload a .csv file")
    raw = await file.read()
    return _process_csv(raw, user_id)
