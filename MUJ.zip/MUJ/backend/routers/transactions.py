"""routers/transactions.py — list + manual recategorize."""
from typing import Optional
from fastapi import APIRouter, Query, HTTPException

from db import db_cursor
from models import TransactionOut, TransactionPatch

router = APIRouter(prefix="/api/transactions", tags=["transactions"])


def _row_to_out(row) -> TransactionOut:
    date_val = row.get("date") or row.get("txn_date", "")
    amount = float(row["amount"])
    t_type = str(row.get("type", "")).lower()
    if t_type == "credit" or t_type == "income" or amount > 0:
        norm_type = "credit"
    else:
        norm_type = "debit"

    return TransactionOut(
        id=row["id"],
        user_id=row["user_id"],
        date=date_val,
        txn_date=date_val,
        merchant=row["merchant"],
        description=row.get("description", ""),
        amount=amount,
        type=norm_type,
        category=row.get("category") or "Other",
        is_essential=bool(row.get("is_essential") or t_type == "essential"),
        is_recurring=bool(row.get("is_recurring", 0)),
        categorized_by=row.get("categorized_by"),
    )


@router.get("", response_model=list[TransactionOut])
def list_transactions(
    user_id: int = Query(1),
    category: Optional[str] = None,
    month: Optional[str] = None,  # "YYYY-MM"
):
    query = "SELECT * FROM transactions WHERE user_id = ?"
    params: list = [user_id]
    if category:
        query += " AND category = ?"
        params.append(category)
    if month:
        query += " AND (date LIKE ? OR date LIKE ?)"
        params.append(f"{month}%")
        params.append(f"{month}%")
    query += " ORDER BY id DESC"

    with db_cursor() as cur:
        cur.execute(query, params)
        rows = [dict(r) for r in cur.fetchall()]
    return [_row_to_out(r) for r in rows]


@router.patch("/{txn_id}", response_model=TransactionOut)
def patch_transaction(txn_id: int, patch: TransactionPatch):
    fields, params = [], []
    if patch.category is not None:
        fields.append("category = ?")
        params.append(patch.category)
    if patch.is_essential is not None:
        fields.append("is_essential = ?")
        params.append(int(patch.is_essential))
    if not fields:
        raise HTTPException(400, "Nothing to update")
    fields.append("categorized_by = ?")
    params.append("manual")
    params.append(txn_id)

    with db_cursor() as cur:
        cur.execute(f"UPDATE transactions SET {', '.join(fields)} WHERE id = ?", params)
        if cur.rowcount == 0:
            raise HTTPException(404, "Transaction not found")
        cur.execute("SELECT * FROM transactions WHERE id = ?", (txn_id,))
        row = cur.fetchone()
    return _row_to_out(row)
