"""routers/liabilities.py — liability CRUD + avalanche ranking."""
from fastapi import APIRouter, Query, HTTPException

from db import db_cursor
from models import LiabilityCreate, LiabilityOut
from engines.liability_engine import rank_liabilities

router = APIRouter(prefix="/api/liabilities", tags=["liabilities"])


@router.get("", response_model=list[LiabilityOut])
def list_liabilities(user_id: int = Query(1)):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM liabilities WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]

    for r in rows:
        r.setdefault("type", "loan")
        r.setdefault("min_payment", 0)

    ranked = rank_liabilities(rows)
    return [LiabilityOut(**li) for li in ranked]


@router.post("", response_model=LiabilityOut)
def create_liability(liability: LiabilityCreate, user_id: int = Query(1)):
    with db_cursor() as cur:
        cur.execute(
            """INSERT INTO liabilities (user_id, name, balance, interest_rate, min_payment)
               VALUES (?, ?, ?, ?, ?)""",
            (user_id, liability.name, liability.balance, liability.interest_rate, liability.min_payment or 0),
        )
        new_id = cur.lastrowid
        cur.execute("SELECT * FROM liabilities WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]

    for r in rows:
        r.setdefault("type", "loan")
        r.setdefault("min_payment", 0)

    ranked = rank_liabilities(rows)
    created = next(li for li in ranked if li["id"] == new_id)
    return LiabilityOut(**created)


@router.delete("/{liability_id}", status_code=204)
def delete_liability(liability_id: int):
    with db_cursor() as cur:
        cur.execute("DELETE FROM liabilities WHERE id = ?", (liability_id,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Liability not found")
