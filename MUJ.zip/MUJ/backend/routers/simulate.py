"""routers/simulate.py — bonus Simulation Mode (BACKEND.md step 9 / PRD §5).

Accepts two request shapes for maximum frontend compatibility:
  { scenario: "new_emi", params: { amount: 12000 } }   ← backend model
  { scenario: "new_emi", amount: 12000 }                ← simple flat shape (auto-normalized)
"""
from datetime import date, datetime
from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel, model_validator
from typing import Optional, Any

from db import db_cursor
from models import SimulateResponse
from engines.cashflow_engine import project_cashflow
from engines.goals_engine import compute_monthly_contribution
from ai.llm_client import narrate_simulation

router = APIRouter(prefix="/api/simulate", tags=["simulate"])

DEFAULT_START_BALANCE = 20000.0


class SimulateRequest(BaseModel):
    scenario: str  # "new_emi" | "rent_change" | "income_change"
    params: Optional[dict] = None
    amount: Optional[float] = None  # flat alias for params.amount

    @model_validator(mode="after")
    def normalize_params(self):
        if self.params is None:
            # Accept flat { scenario, amount } shape from frontend
            self.params = {}
        if self.amount is not None and "amount" not in self.params:
            self.params["amount"] = self.amount
        if "new_amount" not in self.params and "amount" in self.params:
            self.params["new_amount"] = self.params["amount"]
        return self


def _apply_scenario(transactions: list[dict], scenario: str, params: dict, month: str) -> list[dict]:
    """Returns a NEW list with a synthetic transaction added/modified."""
    txns = [dict(t) for t in transactions]

    if scenario == "new_emi":
        amount = float(params.get("amount", params.get("new_amount", 0)))
        start = params.get("start_date", f"{month}-05")
        txns.append({
            "txn_date": start, "merchant": "Simulated New EMI", "amount": amount,
            "type": "debit", "category": "EMI", "is_essential": True,
        })

    elif scenario in ("rent_change", "rent_increase"):
        new_amount = float(params.get("new_amount", params.get("amount", 0)))
        found = False
        for t in txns:
            if t.get("category") == "Rent" and t["txn_date"].startswith(month):
                t["amount"] = new_amount
                found = True
        if not found:
            txns.append({
                "txn_date": f"{month}-01", "merchant": "Simulated Rent Change", "amount": new_amount,
                "type": "debit", "category": "Rent", "is_essential": True,
            })

    elif scenario == "income_change":
        new_amount = float(params.get("new_amount", params.get("amount", 0)))
        found = False
        for t in txns:
            if t.get("category") == "Salary" and t["txn_date"].startswith(month):
                t["amount"] = new_amount
                found = True
        if not found:
            txns.append({
                "txn_date": f"{month}-01", "merchant": "Simulated Income Change", "amount": new_amount,
                "type": "credit", "category": "Salary", "is_essential": True,
            })
    else:
        raise HTTPException(400, f"Unknown scenario: {scenario}. Use: new_emi, rent_change, income_change")

    return txns


def _goal_snapshot(goals_rows: list[dict], surplus: float) -> list[dict]:
    out = []
    for g in goals_rows:
        calc = compute_monthly_contribution(
            g["target_amount"], g["current_amount"], date.fromisoformat(g["target_date"])
        )
        out.append({
            "name": g["name"],
            "monthly_contribution_required": calc["monthly_contribution_required"],
            "months_remaining": calc["months_remaining"],
            "affordable_from_surplus": surplus >= calc["monthly_contribution_required"],
        })
    return out


@router.post("", response_model=SimulateResponse)
def simulate(req: SimulateRequest, user_id: int = Query(1)):
    month = date.today().strftime("%Y-%m")

    with db_cursor() as cur:
        cur.execute("SELECT * FROM transactions WHERE user_id = ?", (user_id,))
        raw_txns = [dict(r) for r in cur.fetchall()]
        cur.execute("SELECT * FROM goals WHERE user_id = ?", (user_id,))
        goals_rows = [dict(r) for r in cur.fetchall()]

    transactions = []
    for r in raw_txns:
        amount = float(r["amount"])
        t_type = str(r.get("type", "")).lower()
        if t_type == "credit" or t_type == "income" or amount > 0:
            norm_type = "credit"
            actual_amount = abs(amount)
        else:
            norm_type = "debit"
            actual_amount = abs(amount)

        date_val = r.get("date") or r.get("txn_date", "")
        transactions.append({
            "id": r["id"],
            "user_id": r["user_id"],
            "txn_date": date_val,
            "date": date_val,
            "merchant": r["merchant"],
            "amount": actual_amount,
            "type": norm_type,
            "category": r.get("category") or "Other",
            "is_essential": bool(r.get("is_essential") or t_type == "essential"),
            "is_recurring": bool(r.get("is_recurring", 0)),
        })

    before_cf = project_cashflow(transactions, DEFAULT_START_BALANCE, month)
    before_surplus = before_cf["recurring_inflow"] - before_cf["recurring_outflow"]
    before = {
        "cashflow": before_cf,
        "goals": _goal_snapshot(goals_rows, before_surplus),
        "projected_balance": before_cf["month_end_balance"],
    }

    modified_txns = _apply_scenario(transactions, req.scenario, req.params, month)
    after_cf = project_cashflow(modified_txns, DEFAULT_START_BALANCE, month)
    after_surplus = after_cf["recurring_inflow"] - after_cf["recurring_outflow"]
    after = {
        "cashflow": after_cf,
        "goals": _goal_snapshot(goals_rows, after_surplus),
        "projected_balance": after_cf["month_end_balance"],
    }

    fallback = (
        f"Month-end balance moves from \u20b9{before_cf['month_end_balance']:,.0f} to "
        f"\u20b9{after_cf['month_end_balance']:,.0f} after applying this scenario."
    )
    narrative = narrate_simulation(req.scenario, before, after, fallback)

    return SimulateResponse(before=before, after=after, narrative=narrative)
