"""routers/dashboard.py — aggregated summary for the main screen.

GET /api/dashboard/summary returns DashboardSummary which the frontend maps to:
  total_income, total_expense, by_category (list), recurring_subscriptions (list)
"""
from collections import defaultdict
from fastapi import APIRouter, Query

from db import db_cursor
from models import DashboardSummary, CategoryBreakdown, RecurringSubscription
from engines.recurring import detect_recurring

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary", response_model=DashboardSummary)
def dashboard_summary(user_id: int = Query(1)):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM transactions WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]

    norm_rows = []
    for r in rows:
        amount = float(r["amount"])
        t_type = str(r.get("type", "")).lower()
        if t_type == "credit" or t_type == "income" or amount > 0:
            norm_type = "credit"
            actual_amount = abs(amount)
        else:
            norm_type = "debit"
            actual_amount = abs(amount)

        date_val = r.get("date") or r.get("txn_date", "")
        norm_rows.append({
            "id": r["id"],
            "user_id": r["user_id"],
            "txn_date": date_val,
            "date": date_val,
            "merchant": r["merchant"],
            "amount": actual_amount,
            "type": norm_type,
            "category": r.get("category") or "Other",
            "is_essential": bool(r.get("is_essential") or t_type == "essential"),
            "is_recurring": bool(r.get("is_recurring", 0)),
        })

    total_income = sum(r["amount"] for r in norm_rows if r["type"] == "credit")
    total_expense = sum(r["amount"] for r in norm_rows if r["type"] == "debit")

    by_category: dict = defaultdict(lambda: {"amount": 0.0, "essential_flags": set()})
    for r in norm_rows:
        if r["type"] != "debit":
            continue
        cat = r["category"] or "Other"
        by_category[cat]["amount"] += r["amount"]
        by_category[cat]["essential_flags"].add(bool(r["is_essential"]))

    breakdown = []
    for cat, agg in sorted(by_category.items(), key=lambda kv: -kv[1]["amount"]):
        flags = agg["essential_flags"]
        essential = flags.pop() if len(flags) == 1 else None
        breakdown.append(CategoryBreakdown(category=cat, amount=round(agg["amount"], 2), essential=essential))

    recurring_stats = detect_recurring(norm_rows)
    merchant_category = {}
    for r in norm_rows:
        merchant_category.setdefault(r["merchant"], r["category"])

    subs = [
        RecurringSubscription(
            merchant=m,
            amount=s["avg_amount"],
            category=merchant_category.get(m),
            frequency_days=s["frequency_days"],
        )
        for m, s in recurring_stats.items()
        if s["is_recurring"]
    ]

    return DashboardSummary(
        total_income=round(total_income, 2),
        total_expense=round(total_expense, 2),
        by_category=breakdown,
        recurring_subscriptions=subs,
    )
