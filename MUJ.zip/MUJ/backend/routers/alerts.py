"""routers/alerts.py — generate + list alerts. Numbers are deterministic
(engines/alerts_engine.py); `message` is LLM-narrated with a template fallback."""
import json
from datetime import date, datetime
from fastapi import APIRouter, Query

from db import db_cursor
from models import AlertOut
from engines.alerts_engine import generate_all_alerts
from ai.llm_client import narrate_alert

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


def _fallback_message(alert: dict) -> str:
    n = alert["numbers"]
    if alert["type"] == "overspend":
        return (
            f"You've spent \u20b9{n['this_month_spend']:,.0f} on {n['category']} this month, "
            f"vs an average of \u20b9{n['avg_last_3_months']:,.0f} over the last 3 months "
            f"(threshold \u20b9{n['threshold_1_3x']:,.0f})."
        )
    if alert["type"] == "large_upcoming_debit":
        return (
            f"{n['merchant']} takes \u20b9{n['amount']:,.0f}, which is {n['pct_of_income']}% of your "
            f"average monthly income of \u20b9{n['avg_monthly_income']:,.0f} "
            f"(threshold {n['threshold_pct']}%)."
        )
    if alert["type"] == "unused_subscription":
        return (
            f"{n['merchant']} (\u20b9{n['amount']:,.0f} every ~{n['frequency_days']:.0f} days) shows no "
            f"usage signal in the last {n['no_usage_detected_days']} days."
        )
    return "Alert triggered."


def _row_to_out(row) -> AlertOut:
    data_raw = row.get("data_json") or row.get("numbers_json") or "{}"
    numbers = json.loads(data_raw) if isinstance(data_raw, str) else (data_raw or {})
    severity = row.get("severity") or "warning"
    title = row.get("title") or row["type"].replace("_", " ").title()
    return AlertOut(
        id=row["id"], user_id=row["user_id"], type=row["type"], severity=severity,
        title=title, message=row["message"], numbers=numbers,
        created_at=row.get("created_at") or "",
    )


@router.get("", response_model=list[AlertOut])
def list_alerts(user_id: int = Query(1)):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM alerts WHERE user_id = ? ORDER BY id DESC", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]
    return [_row_to_out(r) for r in rows]


@router.post("/generate", response_model=list[AlertOut])
def generate_alerts(user_id: int = Query(1)):
    current_month = date.today().strftime("%Y-%m")
    with db_cursor() as cur:
        cur.execute("SELECT * FROM transactions WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]

    norm_rows = []
    for r in rows:
        amount = float(r["amount"])
        t_type = str(r.get("type", "")).lower()
        if t_type == "credit" or t_type == "income" or amount > 0:
            norm_type = "credit"
            actual_amount = abs(amount)
        else:
            norm_type = "debit"
            actual_amount = abs(amount)

        date_val = r.get("date") or r.get("txn_date", "")
        norm_rows.append({
            "id": r["id"],
            "user_id": r["user_id"],
            "txn_date": date_val,
            "date": date_val,
            "merchant": r["merchant"],
            "amount": actual_amount,
            "type": norm_type,
            "category": r.get("category") or "Other",
            "is_essential": bool(r.get("is_essential") or t_type == "essential"),
            "is_recurring": bool(r.get("is_recurring", 0)),
        })

    computed = generate_all_alerts(norm_rows, current_month)

    with db_cursor() as cur:
        cur.execute("DELETE FROM alerts WHERE user_id = ?", (user_id,))
        saved = []
        for alert in computed:
            message = narrate_alert(alert["type"], alert["numbers"], _fallback_message(alert))
            created_at = datetime.utcnow().isoformat()
            cur.execute(
                """INSERT INTO alerts (user_id, type, message, data_json, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (user_id, alert["type"], message, json.dumps(alert["numbers"]), created_at),
            )
            saved.append(AlertOut(
                id=cur.lastrowid, user_id=user_id, type=alert["type"], severity=alert.get("severity", "warning"),
                title=alert.get("title", alert["type"]), message=message, numbers=alert["numbers"], created_at=created_at,
            ))
    return saved
