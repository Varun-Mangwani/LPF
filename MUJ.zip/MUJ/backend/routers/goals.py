"""routers/goals.py — goal CRUD + computed monthly contribution."""
from datetime import date, datetime
from fastapi import APIRouter, Query, HTTPException

from db import db_cursor
from models import GoalCreate, GoalOut
from engines.goals_engine import compute_monthly_contribution

router = APIRouter(prefix="/api/goals", tags=["goals"])


def _row_to_out(row) -> GoalOut:
    target_d = date.fromisoformat(row["target_date"])
    calc = compute_monthly_contribution(row["target_amount"], row["current_amount"], target_d)
    return GoalOut(
        id=row["id"],
        user_id=row["user_id"],
        name=row["name"],
        target_amount=row["target_amount"],
        current_amount=row["current_amount"],
        target_date=row["target_date"],
        monthly_contribution_required=calc["monthly_contribution_required"],
        months_remaining=calc["months_remaining"],
        created_at=row.get("created_at") or "",
    )


@router.get("", response_model=list[GoalOut])
def list_goals(user_id: int = Query(1)):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM goals WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]
    return [_row_to_out(r) for r in rows]


@router.post("", response_model=GoalOut)
def create_goal(goal: GoalCreate, user_id: int = Query(1)):
    calc = compute_monthly_contribution(goal.target_amount, goal.current_amount, goal.target_date)
    with db_cursor() as cur:
        cur.execute(
            """INSERT INTO goals (user_id, name, target_amount, current_amount, target_date)
               VALUES (?, ?, ?, ?, ?)""",
            (
                user_id, goal.name, goal.target_amount, goal.current_amount,
                goal.target_date.isoformat(),
            ),
        )
        goal_id = cur.lastrowid
        cur.execute("SELECT * FROM goals WHERE id = ?", (goal_id,))
        row = dict(cur.fetchone())
    return _row_to_out(row)


@router.put("/{goal_id}", response_model=GoalOut)
def update_goal(goal_id: int, goal: GoalCreate):
    with db_cursor() as cur:
        cur.execute(
            """UPDATE goals SET name = ?, target_amount = ?, current_amount = ?,
                                 target_date = ? WHERE id = ?""",
            (
                goal.name, goal.target_amount, goal.current_amount,
                goal.target_date.isoformat(), goal_id,
            ),
        )
        if cur.rowcount == 0:
            raise HTTPException(404, "Goal not found")
        cur.execute("SELECT * FROM goals WHERE id = ?", (goal_id,))
        row = dict(cur.fetchone())
    return _row_to_out(row)


@router.delete("/{goal_id}", status_code=204)
def delete_goal(goal_id: int):
    with db_cursor() as cur:
        cur.execute("DELETE FROM goals WHERE id = ?", (goal_id,))
        if cur.rowcount == 0:
            raise HTTPException(404, "Goal not found")
