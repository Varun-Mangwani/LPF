"""routers/cashflow.py — projected month-end balance.

Exposes:
  GET /api/cashflow          (used by the frontend)
  GET /api/cashflow/projection  (alias)
"""
from datetime import date
from fastapi import APIRouter, Query

from db import db_cursor
from models import CashflowResponse
from engines.cashflow_engine import project_cashflow

router = APIRouter(prefix="/api/cashflow", tags=["cashflow"])

DEFAULT_START_BALANCE = 20000.0  # demo default when no opening-balance source exists


def _get_cashflow(user_id: int, month: str | None, start_balance: float) -> CashflowResponse:
    month = month or date.today().strftime("%Y-%m")
    with db_cursor() as cur:
        cur.execute("SELECT * FROM transactions WHERE user_id = ?", (user_id,))
        rows = [dict(r) for r in cur.fetchall()]

    norm_rows = []
    for r in rows:
        amount = float(r["amount"])
        t_type = str(r.get("type", "")).lower()
        if t_type == "credit" or t_type == "income" or amount > 0:
            norm_type = "credit"
            actual_amount = abs(amount)
        else:
            norm_type = "debit"
            actual_amount = abs(amount)

        date_val = r.get("date") or r.get("txn_date", "")
        norm_rows.append({
            "id": r["id"],
            "user_id": r["user_id"],
            "txn_date": date_val,
            "date": date_val,
            "merchant": r["merchant"],
            "amount": actual_amount,
            "type": norm_type,
            "category": r.get("category") or "Other",
            "is_essential": bool(r.get("is_essential") or t_type == "essential"),
            "is_recurring": bool(r.get("is_recurring", 0)),
        })

    result = project_cashflow(norm_rows, start_balance, month)
    return CashflowResponse(**result)


@router.get("", response_model=CashflowResponse)
def cashflow_root(
    user_id: int = Query(1),
    month: str | None = Query(None, description="YYYY-MM, defaults to current month"),
    start_balance: float = Query(DEFAULT_START_BALANCE),
):
    return _get_cashflow(user_id, month, start_balance)


@router.get("/projection", response_model=CashflowResponse)
def cashflow_projection(
    user_id: int = Query(1),
    month: str | None = Query(None, description="YYYY-MM, defaults to current month"),
    start_balance: float = Query(DEFAULT_START_BALANCE),
):
    return _get_cashflow(user_id, month, start_balance)
