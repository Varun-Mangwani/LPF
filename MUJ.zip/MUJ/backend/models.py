"""models.py — Pydantic request/response models (see API_CONTRACT.md)"""
from datetime import date
from typing import Optional, List, Literal
from pydantic import BaseModel, Field


# ---------- Transactions ----------

class TransactionOut(BaseModel):
    id: int
    user_id: int
    date: str
    txn_date: Optional[str] = None
    merchant: str
    description: Optional[str] = ""
    amount: float
    type: str
    category: Optional[str] = "Other"
    is_essential: Optional[bool] = False
    is_recurring: bool = False
    categorized_by: Optional[str] = None


class TransactionPatch(BaseModel):
    category: Optional[str] = None
    is_essential: Optional[bool] = None


class UploadResponse(BaseModel):
    inserted: int
    categorized_by_rule: int
    categorized_by_llm: int
    recurring_detected: int


# ---------- Dashboard ----------

class CategoryBreakdown(BaseModel):
    category: str
    amount: float
    essential: Optional[bool] = None


class RecurringSubscription(BaseModel):
    merchant: str
    amount: float
    category: Optional[str] = None
    frequency_days: Optional[float] = None


class DashboardSummary(BaseModel):
    total_income: float
    total_expense: float
    by_category: List[CategoryBreakdown]
    recurring_subscriptions: List[RecurringSubscription]


# ---------- Cash Flow ----------

class DailyBalance(BaseModel):
    date: str
    balance: float


class CashflowResponse(BaseModel):
    start_balance: float
    days: List[DailyBalance]
    month_end_balance: float
    recurring_inflow: float
    recurring_outflow: float
    avg_daily_discretionary: float


# ---------- Goals ----------

class GoalCreate(BaseModel):
    name: str
    target_amount: float = Field(gt=0)
    current_amount: float = 0
    target_date: date


class GoalOut(BaseModel):
    id: int
    user_id: int
    name: str
    target_amount: float
    current_amount: float
    target_date: str
    monthly_contribution_required: Optional[float] = None
    months_remaining: Optional[int] = None
    created_at: str


# ---------- Liabilities ----------

class LiabilityCreate(BaseModel):
    name: str
    type: Optional[str] = "loan"
    balance: float = Field(gt=0)
    interest_rate: float = Field(ge=0)
    min_payment: Optional[float] = 0


class LiabilityOut(BaseModel):
    id: int
    user_id: int
    name: str
    type: Optional[str] = "loan"
    balance: float
    interest_rate: float
    min_payment: Optional[float] = 0
    true_annual_cost: float
    priority_rank: int
    reasoning: str


# ---------- Alerts ----------

class AlertOut(BaseModel):
    id: int
    user_id: int
    type: str
    severity: Optional[str] = "warning"
    title: Optional[str] = "Alert"
    message: str
    numbers: dict
    created_at: Optional[str] = None


# ---------- Simulate ----------

class SimulateRequest(BaseModel):
    scenario: Literal["new_emi", "rent_change", "income_change"]
    params: dict


class SimulateResponse(BaseModel):
    before: dict
    after: dict
    narrative: str
