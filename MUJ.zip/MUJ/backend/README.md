# Personal Financial Health Assistant — Backend

FastAPI backend for the FinTech PS #3 hackathon build, implemented per
`docs/` (PRD, BACKEND.md build spec, DATABASE.md schema, API_CONTRACT.md,
AI_INTEGRATION.md).

## Design principle

> Deterministic code calculates the numbers. AI classifies ambiguous data and
> explains the numbers in plain language. AI never invents a financial figure.

Every `engines/*.py` module is a pure function: numbers in, numbers out, no
DB access, no LLM calls, independently testable. The LLM is only reached from
`engines/categorizer.py` (merchant → category fallback) and from the
alert/simulation narration steps — and even there, the actual **numbers** are
always computed first by the pure engines and just handed to the LLM to phrase.

## Setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
cp .env.example .env    # optional: add ANTHROPIC_API_KEY to enable real LLM calls
uvicorn main:app --reload --port 8000
```

The app runs fully offline with **no API key** — categorization falls back to
`"Other"`/discretionary, and alert/simulation text falls back to a
deterministic template. This is intentional so the demo never depends on
network access at judging time.

On first startup, `db.py` creates `data/finhealth.db` (SQLite) and seeds two
demo users (`id=1`, `id=2`).

## Load demo data

Two ready-made CSVs simulate four months (Jun–Sep 2026) of a salaried user's
transactions — salary, rent, EMI, subscriptions, groceries, food delivery,
transport, shopping, utilities, and a SIP — with September's food-delivery
spend deliberately inflated so the overspend alert fires on demo data.

```bash
# with the server running:
python scripts/load_seed.py
```

Or upload manually: `POST /api/upload/csv?user_id=1` with
`data/seed_transactions_user1.csv` as the `file` field (e.g. via the
interactive docs at `http://localhost:8000/docs`).

Add a couple of liabilities for the "pay this first" demo, e.g. via
`POST /api/liabilities?user_id=1`:
```json
{"name": "HDFC Credit Card", "type": "card", "balance": 45000, "interest_rate": 42, "min_payment": 2000}
{"name": "Car Loan", "type": "loan", "balance": 220000, "interest_rate": 9.5, "min_payment": 9500}
```

Then generate alerts: `POST /api/alerts/generate?user_id=1`.

## Endpoints

See `docs/API_CONTRACT.md`, or the auto-generated interactive docs at
`http://localhost:8000/docs` once the server is running.

## Folder structure

```
backend/
  main.py, db.py, models.py
  routers/     upload, transactions, dashboard, cashflow, goals, liabilities, alerts, simulate
  engines/     categorizer, recurring, cashflow_engine, goals_engine, liability_engine, alerts_engine
  ai/          llm_client, prompts
  data/        finhealth.db (created at runtime), seed_transactions_user{1,2}.csv
  scripts/     load_seed.py
  docs/        PRD-adjacent build docs (DATABASE.md, API_CONTRACT.md, AI_INTEGRATION.md)
```

## What's out of scope (per PRD §6)

No real bank/Account Aggregator integration, no auth, no mobile app, no
real-time sync. `user_id` is a plain query-param switch between the two demo
profiles, not a security boundary.
