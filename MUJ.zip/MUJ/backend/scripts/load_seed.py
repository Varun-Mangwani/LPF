"""scripts/load_seed.py — pushes the two seed CSVs into a running API.

Usage (with the server already running on :8000):
    python scripts/load_seed.py
"""
import sys
from pathlib import Path

import requests

BASE = "http://localhost:8000"
DATA_DIR = Path(__file__).parent.parent / "data"

SEED_FILES = {
    1: DATA_DIR / "seed_transactions_user1.csv",
    2: DATA_DIR / "seed_transactions_user2.csv",
}


def main():
    for user_id, path in SEED_FILES.items():
        if not path.exists():
            print(f"Missing seed file: {path}", file=sys.stderr)
            continue
        with open(path, "rb") as f:
            resp = requests.post(
                f"{BASE}/api/upload/csv",
                params={"user_id": user_id},
                files={"file": (path.name, f, "text/csv")},
            )
        if resp.ok:
            print(f"user_id={user_id}: {resp.json()}")
        else:
            print(f"user_id={user_id} FAILED: {resp.status_code} {resp.text}", file=sys.stderr)


if __name__ == "__main__":
    main()
