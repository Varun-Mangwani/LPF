"""main.py — FastAPI app, route registration, CORS (BACKEND.md).

Run with:  uvicorn main:app --reload --port 8000
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from db import init_db
from routers import upload, transactions, dashboard, cashflow, goals, liabilities, alerts, simulate

app = FastAPI(
    title="Personal Financial Health Assistant API",
    description="Deterministic engines calculate the numbers; AI only classifies and narrates. See PRD §8.",
    version="1.0.0",
)

# CORS — allow all origins, explicit Vercel origins, and Vercel preview URLs
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "*",
        "https://lpf-five.vercel.app",
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
    ],
    allow_origin_regex=r"^https:\/\/.*\.vercel\.app$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



@app.on_event("startup")
def on_startup():
    init_db(seed=True)


@app.get("/", tags=["health"])
@app.get("/health", tags=["health"])
@app.get("/api/health", tags=["health"])
def health():
    return {"status": "ok", "message": "Personal Financial Health Assistant API", "version": "1.0.0"}


@app.post("/admin/reset", tags=["admin"])
@app.post("/api/admin/reset", tags=["admin"])
def reset():
    """Wipe and re-seed the demo database. Useful for repeated demo runs."""
    from db import reset_db
    reset_db()
    return {"status": "reset_complete"}


# Include routers with /api prefix
app.include_router(upload.router)
app.include_router(transactions.router)
app.include_router(dashboard.router)
app.include_router(cashflow.router)
app.include_router(goals.router)
app.include_router(liabilities.router)
app.include_router(alerts.router)
app.include_router(simulate.router)

# Include routers without /api prefix to support API_CONTRACT.md direct paths
app.include_router(upload.router, prefix="", tags=["upload-root"])
app.include_router(transactions.router, prefix="", tags=["transactions-root"])
app.include_router(dashboard.router, prefix="", tags=["dashboard-root"])
app.include_router(cashflow.router, prefix="", tags=["cashflow-root"])
app.include_router(goals.router, prefix="", tags=["goals-root"])
app.include_router(liabilities.router, prefix="", tags=["liabilities-root"])
app.include_router(alerts.router, prefix="", tags=["alerts-root"])
app.include_router(simulate.router, prefix="", tags=["simulate-root"])
