"""ai/llm_client.py — thin wrapper around the Anthropic Messages API.

Design rule (PRD §8 / BACKEND.md): the LLM is used ONLY for merchant
categorization fallback and for narrating already-computed numbers. It never
computes a figure. This module also has to work with NO API key set (hackathon
demo on a machine with no network) — every public function degrades to a
deterministic, clearly-labelled fallback instead of throwing.
"""
import json
import os
import re
from typing import List, Dict

from ai.prompts import (
    build_categorization_prompt,
    build_alert_narration_prompt,
    build_simulation_narration_prompt,
)

MODEL = "claude-sonnet-4-6"
API_URL = "https://api.anthropic.com/v1/messages"


def _api_key() -> str | None:
    return os.environ.get("ANTHROPIC_API_KEY")


def _call_llm(system: str, user: str, max_tokens: int = 800) -> str | None:
    """Returns raw text response, or None if no key / call failed."""
    key = _api_key()
    if not key:
        return None
    try:
        import requests  # local import so the module still loads without it

        resp = requests.post(
            API_URL,
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": MODEL,
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": "user", "content": user}],
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        return "\n".join(text_blocks) if text_blocks else None
    except Exception:
        # Never let an LLM/network hiccup break the deterministic app.
        return None


def _strip_json_fences(text: str) -> str:
    return re.sub(r"^```(json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()


def classify_merchants_llm(merchants: List[str], categories: List[str]) -> Dict[str, dict]:
    """Batch-classify unmatched merchants. Falls back to 'Other' / discretionary
    for every merchant if the LLM is unavailable, so the pipeline never blocks."""
    if not merchants:
        return {}

    prompt = build_categorization_prompt(merchants, categories)
    raw = _call_llm(prompt["system"], prompt["user"])

    if raw is None:
        return {m: {"category": "Other", "essential": False} for m in merchants}

    try:
        parsed = json.loads(_strip_json_fences(raw))
        # Guard against categories outside the fixed enum.
        cleaned = {}
        for merchant in merchants:
            entry = parsed.get(merchant, {})
            category = entry.get("category") if entry.get("category") in categories else "Other"
            cleaned[merchant] = {
                "category": category,
                "essential": bool(entry.get("essential", False)),
            }
        return cleaned
    except (json.JSONDecodeError, AttributeError):
        return {m: {"category": "Other", "essential": False} for m in merchants}


def narrate_alert(alert_type: str, numbers: dict, fallback: str) -> str:
    """Turn a computed alert into a plain-language sentence. `fallback` is a
    deterministic template the caller supplies, used if the LLM is unavailable."""
    prompt = build_alert_narration_prompt(alert_type, numbers)
    raw = _call_llm(prompt["system"], prompt["user"], max_tokens=200)
    return raw.strip() if raw else fallback


def narrate_simulation(scenario: str, before: dict, after: dict, fallback: str) -> str:
    prompt = build_simulation_narration_prompt(scenario, before, after)
    raw = _call_llm(prompt["system"], prompt["user"], max_tokens=200)
    return raw.strip() if raw else fallback
