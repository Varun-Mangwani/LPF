"""ai/prompts.py — prompt templates (see docs/AI_INTEGRATION.md)

Kept as plain string builders so llm_client.py stays a thin transport layer.
"""
import json
from typing import List, Dict

CATEGORIZATION_SYSTEM = """You are a transaction categorizer for an Indian personal finance app.
Classify each merchant into exactly one category from this fixed list:
{categories}
Also say whether it is "essential" or "discretionary".
Return ONLY valid JSON mapping merchant -> {{"category": ..., "essential": true|false}}.
No prose, no markdown code fences, no extra keys."""

NARRATION_SYSTEM = """You explain personal-finance numbers in one or two plain sentences for an
Indian salaried user. You are given the exact numbers to use — do not invent,
round dramatically, or add numbers not provided. No disclaimers, just the
explanation. Use the Rupee symbol (\u20b9) for amounts."""


def build_categorization_prompt(merchants: List[str], categories: List[str]) -> Dict[str, str]:
    system = CATEGORIZATION_SYSTEM.format(categories=", ".join(categories))
    user = json.dumps({"merchants": merchants})
    return {"system": system, "user": user}


def build_alert_narration_prompt(alert_type: str, numbers: dict) -> Dict[str, str]:
    user = (
        f"Alert type: {alert_type}\n"
        f"Numbers: {json.dumps(numbers)}\n"
        "Write one or two sentences explaining why this alert triggered, "
        "using only the numbers given above."
    )
    return {"system": NARRATION_SYSTEM, "user": user}


def build_simulation_narration_prompt(scenario: str, before: dict, after: dict) -> Dict[str, str]:
    user = (
        f"Scenario: {scenario}\n"
        f"Before: {json.dumps(before)}\n"
        f"After: {json.dumps(after)}\n"
        "Write one or two sentences summarizing the impact of this change, "
        "using only the before/after numbers given above."
    )
    return {"system": NARRATION_SYSTEM, "user": user}
