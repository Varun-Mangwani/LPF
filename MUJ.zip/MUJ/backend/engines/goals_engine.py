"""engines/goals_engine.py — goal math (BACKEND.md step 6). Pure functions only."""
from datetime import date


def months_remaining(target_date: date, today: date | None = None) -> int:
    today = today or date.today()
    months = (target_date.year - today.year) * 12 + (target_date.month - today.month)
    # If the target day-of-month hasn't arrived yet this "final" month, don't round down to 0.
    if target_date.day < today.day:
        months -= 1
    return max(months, 1)  # never divide by zero; 1 = "due this month"


def compute_monthly_contribution(
    target_amount: float, current_amount: float, target_date: date, today: date | None = None
) -> dict:
    remaining = max(target_amount - current_amount, 0.0)
    months = months_remaining(target_date, today)
    monthly = remaining / months
    return {
        "monthly_contribution_required": round(monthly, 2),
        "months_remaining": months,
        "amount_remaining": round(remaining, 2),
    }
