"""engines/categorizer.py — rules first, LLM fallback for the rest.

Pure-ish function: `categorize(merchants)` takes a list of merchant strings
and returns a dict merchant -> (category, essential, source). No DB access
here — the router owns persistence, per BACKEND.md "every engine function
must be pure".
"""
from typing import List, Dict, Tuple
from ai.llm_client import classify_merchants_llm

# category, is_essential
RULES: Dict[str, Tuple[str, bool]] = {
    "swiggy": ("Food", False),
    "zomato": ("Food", False),
    "dominos": ("Food", False),
    "blinkit": ("Groceries", True),
    "zepto": ("Groceries", True),
    "bigbasket": ("Groceries", True),
    "dmart": ("Groceries", True),
    "netflix": ("Subscription", False),
    "spotify": ("Subscription", False),
    "hotstar": ("Subscription", False),
    "prime video": ("Subscription", False),
    "amazon prime": ("Subscription", False),
    "youtube premium": ("Subscription", False),
    "gym": ("Subscription", False),
    "cult.fit": ("Subscription", False),
    "rent": ("Rent", True),
    "landlord": ("Rent", True),
    "emi": ("EMI", True),
    "loan": ("EMI", True),
    "electricity": ("Utilities", True),
    "bses": ("Utilities", True),
    "water bill": ("Utilities", True),
    "airtel": ("Utilities", True),
    "jio": ("Utilities", True),
    "broadband": ("Utilities", True),
    "uber": ("Transport", False),
    "ola": ("Transport", False),
    "rapido": ("Transport", False),
    "irctc": ("Transport", False),
    "petrol": ("Transport", True),
    "hpcl": ("Transport", True),
    "indian oil": ("Transport", True),
    "amazon": ("Shopping", False),
    "flipkart": ("Shopping", False),
    "myntra": ("Shopping", False),
    "ajio": ("Shopping", False),
    "apollo pharmacy": ("Health", True),
    "practo": ("Health", True),
    "pharmeasy": ("Health", True),
    "hospital": ("Health", True),
    "pvr": ("Entertainment", False),
    "inox": ("Entertainment", False),
    "bookmyshow": ("Entertainment", False),
    "salary": ("Salary", True),
    "payroll": ("Salary", True),
    "zerodha": ("Investment", False),
    "groww": ("Investment", False),
    "mutual fund": ("Investment", False),
    "sip": ("Investment", False),
    "upi transfer": ("Transfer", False),
    "neft": ("Transfer", False),
    "imps": ("Transfer", False),
}

FIXED_CATEGORIES = [
    "Food", "Groceries", "Rent", "EMI", "Subscription", "Utilities",
    "Transport", "Shopping", "Health", "Entertainment", "Transfer",
    "Salary", "Investment", "Other",
]


def _rule_match(merchant: str):
    m = merchant.lower()
    for key, (category, essential) in RULES.items():
        if key in m:
            return category, essential
    return None


def categorize(merchants: List[str]) -> Dict[str, dict]:
    """Return {merchant: {"category": str, "essential": bool, "source": "rule"|"llm"}}"""
    result: Dict[str, dict] = {}
    unmatched: List[str] = []

    for merchant in merchants:
        hit = _rule_match(merchant)
        if hit:
            category, essential = hit
            result[merchant] = {"category": category, "essential": essential, "source": "rule"}
        else:
            unmatched.append(merchant)

    if unmatched:
        llm_result = classify_merchants_llm(unmatched, FIXED_CATEGORIES)
        for merchant in unmatched:
            classified = llm_result.get(merchant)
            if classified:
                result[merchant] = {
                    "category": classified.get("category", "Other"),
                    "essential": bool(classified.get("essential", False)),
                    "source": "llm",
                }
            else:
                result[merchant] = {"category": "Other", "essential": False, "source": "llm"}

    return result
