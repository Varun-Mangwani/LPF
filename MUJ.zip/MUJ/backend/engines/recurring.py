"""engines/recurring.py — flags recurring merchants (BACKEND.md step 4).

Rule: group debit transactions by merchant. If the same merchant appears
>= 2 times, with amounts within +/-10% of each other, at roughly monthly
intervals (25-35 days apart on average), flag every transaction from that
merchant as recurring.

Pure function: takes a list of transaction dicts, returns the set of
merchant names that qualify as recurring, plus per-merchant stats the
callers (dashboard, cashflow) can reuse.
"""
from datetime import date
from statistics import mean
from typing import List, Dict, Set

AMOUNT_TOLERANCE = 0.10
MIN_INTERVAL_DAYS = 25
MAX_INTERVAL_DAYS = 35


def _parse_date(d: str) -> date:
    return date.fromisoformat(d)


def detect_recurring(transactions: List[dict]) -> Dict[str, dict]:
    """
    transactions: list of dicts with keys txn_date, merchant, amount, type
    returns: { merchant: { "is_recurring": bool, "avg_amount": float,
                            "frequency_days": float|None, "count": int } }
    """
    by_merchant: Dict[str, List[dict]] = {}
    for t in transactions:
        if t["type"] != "debit":
            continue
        by_merchant.setdefault(t["merchant"], []).append(t)

    result: Dict[str, dict] = {}
    for merchant, txns in by_merchant.items():
        txns_sorted = sorted(txns, key=lambda t: t["txn_date"])
        amounts = [t["amount"] for t in txns_sorted]
        avg_amount = mean(amounts)

        amounts_consistent = all(
            abs(a - avg_amount) <= AMOUNT_TOLERANCE * avg_amount for a in amounts
        )

        is_recurring = False
        avg_interval = None
        if len(txns_sorted) >= 2 and amounts_consistent:
            dates = [_parse_date(t["txn_date"]) for t in txns_sorted]
            intervals = [(dates[i + 1] - dates[i]).days for i in range(len(dates) - 1)]
            avg_interval = mean(intervals) if intervals else None
            if avg_interval is not None and MIN_INTERVAL_DAYS <= avg_interval <= MAX_INTERVAL_DAYS:
                is_recurring = True

        result[merchant] = {
            "is_recurring": is_recurring,
            "avg_amount": round(avg_amount, 2),
            "frequency_days": round(avg_interval, 1) if avg_interval else None,
            "count": len(txns_sorted),
        }

    return result


def recurring_merchant_set(transactions: List[dict]) -> Set[str]:
    stats = detect_recurring(transactions)
    return {m for m, s in stats.items() if s["is_recurring"]}
