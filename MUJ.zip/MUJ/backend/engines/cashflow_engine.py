"""engines/cashflow_engine.py — projects month-end balance (BACKEND.md step 5).

Pure function. Given this month's transactions (so far) + a start balance,
projects a daily balance array to month-end:
  - recurring inflow (e.g. salary) and recurring outflow (rent, EMI, subs)
    are counted once, on whichever day-of-month they historically land on
  - discretionary (non-recurring, non-essential-fixed) spend is averaged
    per day and projected forward for the remaining days of the month
"""
import calendar
from datetime import date, timedelta
from statistics import mean
from typing import List, Dict

from engines.recurring import recurring_merchant_set

RECURRING_CATEGORIES = {"Rent", "EMI", "Subscription", "Utilities", "Salary"}


def _parse(d: str) -> date:
    return date.fromisoformat(d)


def project_cashflow(
    transactions: List[dict],
    start_balance: float,
    month: str,  # "YYYY-MM"
    today: date | None = None,
) -> dict:
    year, mon = (int(x) for x in month.split("-"))
    days_in_month = calendar.monthrange(year, mon)[1]
    today = today or date.today()
    if today.year != year or today.month != mon:
        today = date(year, mon, 1)

    month_txns = [t for t in transactions if t["txn_date"].startswith(month)]
    recurring_set = recurring_merchant_set(transactions)  # use full history to detect

    recurring_inflow = sum(
        t["amount"] for t in month_txns
        if t["type"] == "credit" and (t["merchant"] in recurring_set or t.get("category") == "Salary")
    )
    recurring_outflow = sum(
        t["amount"] for t in month_txns
        if t["type"] == "debit" and (t["merchant"] in recurring_set or t.get("category") in RECURRING_CATEGORIES)
    )

    discretionary_txns = [
        t for t in month_txns
        if t["type"] == "debit"
        and t["merchant"] not in recurring_set
        and t.get("category") not in RECURRING_CATEGORIES
    ]
    days_elapsed = max(today.day, 1)
    total_discretionary_so_far = sum(t["amount"] for t in discretionary_txns)
    avg_daily_discretionary = total_discretionary_so_far / days_elapsed if days_elapsed else 0.0

    # Build already-known daily deltas from actual transactions this month.
    daily_delta: Dict[int, float] = {d: 0.0 for d in range(1, days_in_month + 1)}
    for t in month_txns:
        day_num = _parse(t["txn_date"]).day
        delta = t["amount"] if t["type"] == "credit" else -t["amount"]
        daily_delta[day_num] += delta

    # For remaining days (after today), add projected average discretionary spend.
    remaining_days = [d for d in range(today.day + 1, days_in_month + 1)]
    for d in remaining_days:
        daily_delta[d] -= avg_daily_discretionary

    balance = start_balance
    days_out = []
    for d in range(1, days_in_month + 1):
        balance += daily_delta[d]
        days_out.append({"date": f"{month}-{d:02d}", "balance": round(balance, 2)})

    return {
        "start_balance": round(start_balance, 2),
        "days": days_out,
        "month_end_balance": round(balance, 2),
        "recurring_inflow": round(recurring_inflow, 2),
        "recurring_outflow": round(recurring_outflow, 2),
        "avg_daily_discretionary": round(avg_daily_discretionary, 2),
    }
