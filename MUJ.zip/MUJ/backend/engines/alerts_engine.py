"""engines/alerts_engine.py — deterministic alert rules (BACKEND.md step 8).

Every alert's numbers are computed here, purely. The LLM (via llm_client) is
only used afterwards, by the caller, to turn `numbers` into `message` text —
this module returns the raw numbers so that step is optional/testable.

Rules:
  - overspend: this month's spend in a category > 1.3x avg of last 3 months
  - large_upcoming_debit: any known recurring debit > 20% of avg monthly income
  - unused_subscription: recurring merchant, category == Entertainment, with
    no "usage" signal in 30+ days (demo heuristic per BACKEND.md step 8)
"""
from collections import defaultdict
from datetime import date
from statistics import mean
from typing import List, Dict

from engines.recurring import detect_recurring

OVERSPEND_MULTIPLIER = 1.3
LARGE_DEBIT_INCOME_PCT = 0.20


def _month_key(d: str) -> str:
    return d[:7]  # "YYYY-MM"


def _prior_months(current_month: str, n: int) -> List[str]:
    y, m = (int(x) for x in current_month.split("-"))
    months = []
    for _ in range(n):
        m -= 1
        if m == 0:
            m = 12
            y -= 1
        months.append(f"{y:04d}-{m:02d}")
    return months


def detect_overspend(transactions: List[dict], current_month: str) -> List[dict]:
    prior = _prior_months(current_month, 3)
    spend_by_month_category: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))

    for t in transactions:
        if t["type"] != "debit":
            continue
        month = _month_key(t["txn_date"])
        category = t.get("category") or "Other"
        spend_by_month_category[month][category] += t["amount"]

    this_month_spend = spend_by_month_category.get(current_month, {})
    alerts = []
    for category, amount in this_month_spend.items():
        history = [spend_by_month_category.get(m, {}).get(category, 0.0) for m in prior]
        history = [h for h in history if h > 0]
        if not history:
            continue
        avg_prior = mean(history)
        threshold = avg_prior * OVERSPEND_MULTIPLIER
        if avg_prior > 0 and amount > threshold:
            alerts.append({
                "type": "overspend",
                "severity": "warning",
                "title": f"Overspending on {category}",
                "numbers": {
                    "category": category,
                    "this_month_spend": round(amount, 2),
                    "avg_last_3_months": round(avg_prior, 2),
                    "threshold_1_3x": round(threshold, 2),
                },
            })
    return alerts


def detect_large_upcoming_debits(transactions: List[dict]) -> List[dict]:
    recurring_stats = detect_recurring(transactions)
    incomes = [t["amount"] for t in transactions if t["type"] == "credit"]
    avg_income = mean(incomes) if incomes else 0.0
    threshold = avg_income * LARGE_DEBIT_INCOME_PCT

    alerts = []
    if avg_income == 0:
        return alerts
    for merchant, stats in recurring_stats.items():
        if stats["is_recurring"] and stats["avg_amount"] > threshold:
            alerts.append({
                "type": "large_upcoming_debit",
                "severity": "warning",
                "title": f"Large recurring debit: {merchant}",
                "numbers": {
                    "merchant": merchant,
                    "amount": stats["avg_amount"],
                    "avg_monthly_income": round(avg_income, 2),
                    "pct_of_income": round(stats["avg_amount"] / avg_income * 100, 1),
                    "threshold_pct": LARGE_DEBIT_INCOME_PCT * 100,
                },
            })
    return alerts


def detect_unused_subscriptions(transactions: List[dict]) -> List[dict]:
    """Demo heuristic (BACKEND.md step 8): recurring + category=='Entertainment'
    counts as unused, since we have no real usage-tracking data source."""
    recurring_stats = detect_recurring(transactions)
    by_merchant_category: Dict[str, str] = {}
    for t in transactions:
        by_merchant_category.setdefault(t["merchant"], t.get("category") or "Other")

    alerts = []
    for merchant, stats in recurring_stats.items():
        if stats["is_recurring"] and by_merchant_category.get(merchant) == "Entertainment":
            alerts.append({
                "type": "unused_subscription",
                "severity": "info",
                "title": f"Possibly unused: {merchant}",
                "numbers": {
                    "merchant": merchant,
                    "amount": stats["avg_amount"],
                    "frequency_days": stats["frequency_days"],
                    "no_usage_detected_days": 30,
                },
            })
    return alerts


def generate_all_alerts(transactions: List[dict], current_month: str) -> List[dict]:
    return (
        detect_overspend(transactions, current_month)
        + detect_large_upcoming_debits(transactions)
        + detect_unused_subscriptions(transactions)
    )
