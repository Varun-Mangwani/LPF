"""engines/liability_engine.py — avalanche ranking (BACKEND.md step 7).

true_annual_cost = balance * (interest_rate / 100)
Sort descending by interest_rate (avalanche method: highest-rate debt first,
because it's the one costing the most per rupee per year) -> priority_rank.
"""
from typing import List


def rank_liabilities(liabilities: List[dict]) -> List[dict]:
    """
    liabilities: list of dicts with keys name, type, balance, interest_rate, min_payment
    returns: same dicts enriched with true_annual_cost, priority_rank, reasoning
    (does not mutate input list items in place; returns new dicts)
    """
    enriched = []
    for li in liabilities:
        true_annual_cost = li["balance"] * (li["interest_rate"] / 100)
        enriched.append({**li, "true_annual_cost": round(true_annual_cost, 2)})

    ranked = sorted(enriched, key=lambda li: li["interest_rate"], reverse=True)
    for i, li in enumerate(ranked, start=1):
        li["priority_rank"] = i
        if i == 1:
            li["reasoning"] = (
                f"Highest interest rate at {li['interest_rate']}% — costs "
                f"\u20b9{li['true_annual_cost']:,.0f}/year on the current balance. "
                "Paying this down first saves the most money (avalanche method)."
            )
        else:
            top_rate = ranked[0]["interest_rate"]
            li["reasoning"] = (
                f"{li['interest_rate']}% interest (vs {top_rate}% on your top-priority debt) — "
                f"\u20b9{li['true_annual_cost']:,.0f}/year. Pay minimums here until higher-rate debt is cleared."
            )
    return ranked
