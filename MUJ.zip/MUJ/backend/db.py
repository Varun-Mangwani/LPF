"""db.py — SQLite connection + init_db()

Single-file SQLite DB, no ORM (kept deliberately simple for hackathon scope).
Every engine function stays pure (see BACKEND.md "Rules"); this module is the
only place that touches the DB directly, alongside the routers.
"""
import csv
import sqlite3
from datetime import datetime
from pathlib import Path
from contextlib import contextmanager

import os

_DEFAULT_DB = Path(__file__).parent / "financial_assistant.db" if not (Path(__file__).parent.parent / "financial_assistant.db").exists() else Path(__file__).parent.parent / "financial_assistant.db"
DB_PATH = Path(os.environ.get("DB_PATH", str(_DEFAULT_DB)))
SEED_CSV_PATH = Path(__file__).parent / "data" / "seed_transactions_user1.csv"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    date            TEXT NOT NULL,
    merchant        TEXT NOT NULL,
    amount          REAL NOT NULL,
    category        TEXT,
    type            TEXT,
    is_recurring    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS goals (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                     INTEGER NOT NULL REFERENCES users(id),
    name                        TEXT NOT NULL,
    target_amount               REAL NOT NULL,
    current_amount              REAL DEFAULT 0,
    target_date                 TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS liabilities (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER NOT NULL REFERENCES users(id),
    name                TEXT NOT NULL,
    balance             REAL NOT NULL,
    interest_rate       REAL NOT NULL,
    min_payment         REAL
);

CREATE TABLE IF NOT EXISTS alerts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    type            TEXT NOT NULL,
    message         TEXT NOT NULL,
    data_json       TEXT,
    created_at      TEXT
);
"""

# Merchant → (category, is_essential) rules for CSV seeding
SEED_RULES = {
    "swiggy": ("Food", False), "zomato": ("Food", False), "dominos": ("Food", False),
    "blinkit": ("Groceries", True), "zepto": ("Groceries", True), "bigbasket": ("Groceries", True),
    "netflix": ("Subscription", False), "spotify": ("Subscription", False),
    "pvr": ("Entertainment", False), "amazon prime": ("Subscription", False),
    "cult.fit": ("Subscription", False),
    "landlord": ("Rent", True), "rent": ("Rent", True),
    "emi auto debit": ("EMI", True), "car loan": ("EMI", True),
    "electricity": ("Utilities", True), "bses": ("Utilities", True),
    "airtel": ("Utilities", True),
    "rapido": ("Transport", False), "uber": ("Transport", False), "ola": ("Transport", False),
    "zerodha": ("Investment", False), "sip": ("Investment", False),
    "salary": ("Salary", True), "payroll": ("Salary", True),
    "flipkart": ("Shopping", False), "amazon": ("Shopping", False), "myntra": ("Shopping", False),
    "practo": ("Health", True),
}


def _categorize_merchant(merchant: str):
    m = merchant.lower()
    for key, (cat, ess) in SEED_RULES.items():
        if key in m:
            return cat, ess
    return "Other", False


def get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_cursor():
    """Context manager yielding a cursor, committing on success, closing always."""
    conn = get_conn()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    finally:
        conn.close()


def _seed_transactions(cur, user_id: int):
    """Read seed CSV and insert categorized transactions for the user."""
    if not SEED_CSV_PATH.exists():
        return

    cur.execute("SELECT COUNT(*) AS c FROM transactions WHERE user_id = ?", (user_id,))
    if cur.fetchone()["c"] > 0:
        return  # already seeded

    rows = []
    with open(SEED_CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            amount = abs(float(row["amount"]))
            txn_type = row["type"].strip().lower()
            merchant = row["merchant"].strip()
            description = row.get("description", "").strip()
            date_str = row["date"].strip()
            cat, essential = _categorize_merchant(merchant)
            rows.append((user_id, date_str, merchant, description, amount, txn_type, cat, int(essential), "rule"))

    cur.executemany(
        """INSERT INTO transactions
           (user_id, txn_date, merchant, description, amount, type, category, is_essential, categorized_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        rows,
    )

    # Mark recurring merchants (same merchant ≥2 times on debits)
    from collections import Counter
    debit_merchants = [r[2] for r in rows if r[5] == "debit"]
    counts = Counter(debit_merchants)
    recurring = {m for m, c in counts.items() if c >= 2}
    if recurring:
        placeholders = ",".join("?" * len(recurring))
        cur.execute(
            f"UPDATE transactions SET is_recurring = 1 WHERE user_id = ? AND merchant IN ({placeholders})",
            (user_id, *recurring),
        )


def _seed_liabilities(cur, user_id: int):
    cur.execute("SELECT COUNT(*) AS c FROM liabilities WHERE user_id = ?", (user_id,))
    if cur.fetchone()["c"] > 0:
        return
    cur.executemany(
        "INSERT INTO liabilities (user_id, name, type, balance, interest_rate, min_payment) VALUES (?,?,?,?,?,?)",
        [
            (user_id, "Credit Card — HDFC Millennia", "card", 34500, 42.0, 1725),
            (user_id, "Car Loan — EMI", "loan", 286000, 9.5, 9500),
        ],
    )


def _seed_goals(cur, user_id: int):
    cur.execute("SELECT COUNT(*) AS c FROM goals WHERE user_id = ?", (user_id,))
    if cur.fetchone()["c"] > 0:
        return
    now = datetime.utcnow().isoformat()
    cur.executemany(
        """INSERT INTO goals (user_id, name, target_amount, current_amount, target_date,
                               monthly_contribution_req, created_at) VALUES (?,?,?,?,?,?,?)""",
        [
            (user_id, "Emergency Fund", 150000, 42000, "2027-03-01", 18000, now),
            (user_id, "Vacation Fund", 60000, 5000, "2027-06-01", 6111, now),
        ],
    )


def init_db(seed: bool = True):
    """Create tables if missing, and seed demo data on first run."""
    with db_cursor() as cur:
        cur.executescript(SCHEMA)
        if seed:
            cur.execute("SELECT COUNT(*) AS c FROM users")
            if cur.fetchone()["c"] == 0:
                cur.executemany(
                    "INSERT INTO users (id, name) VALUES (?, ?)",
                    [(1, "Demo User 1"), (2, "Demo User 2")],
                )
            _seed_transactions(cur, 1)
            _seed_liabilities(cur, 1)
            _seed_goals(cur, 1)


def reset_db():
    """Danger: wipes all data and re-seeds. Handy for repeat demo runs."""
    if DB_PATH.exists():
        DB_PATH.unlink()
    init_db(seed=True)
