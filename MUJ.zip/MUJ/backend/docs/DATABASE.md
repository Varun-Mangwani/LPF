# DATABASE.md — SQLite Schema

No auth in scope (see PRD Non-Goals), but the demo ships two seed users so the
judge can flip between profiles. `user_id` is just an integer switch, not a
security boundary.

```sql
CREATE TABLE IF NOT EXISTS users (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    txn_date        TEXT NOT NULL,              -- ISO date YYYY-MM-DD
    merchant        TEXT NOT NULL,
    description     TEXT,
    amount          REAL NOT NULL,              -- always positive
    type            TEXT NOT NULL CHECK(type IN ('credit','debit')),
    category        TEXT,                       -- e.g. Food, Rent, EMI, Subscription...
    is_essential    INTEGER,                    -- 0/1, null until categorized
    is_recurring    INTEGER NOT NULL DEFAULT 0,  -- 0/1, set by recurring.py
    categorized_by  TEXT                         -- 'rule' | 'llm' | 'manual' | null
);

CREATE TABLE IF NOT EXISTS goals (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                     INTEGER NOT NULL REFERENCES users(id),
    name                        TEXT NOT NULL,
    target_amount               REAL NOT NULL,
    current_amount              REAL NOT NULL DEFAULT 0,
    target_date                 TEXT NOT NULL,   -- ISO date
    monthly_contribution_req    REAL,            -- computed, cached
    created_at                  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS liabilities (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    name            TEXT NOT NULL,
    type            TEXT NOT NULL CHECK(type IN ('loan','card')),
    balance         REAL NOT NULL,
    interest_rate   REAL NOT NULL,               -- annual %, e.g. 13.5
    min_payment     REAL NOT NULL DEFAULT 0,
    true_annual_cost REAL,                       -- computed, cached
    priority_rank   INTEGER                      -- computed, cached (1 = pay first)
);

CREATE TABLE IF NOT EXISTS alerts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    type            TEXT NOT NULL,   -- overspend | large_upcoming_debit | unused_subscription
    severity        TEXT NOT NULL,   -- info | warning | critical
    title           TEXT NOT NULL,
    message         TEXT NOT NULL,   -- LLM-narrated, numbers-grounded
    numbers_json    TEXT NOT NULL,   -- raw numbers behind the alert (source of truth)
    created_at      TEXT NOT NULL
);
```

Indexes worth adding once data volume matters: `transactions(user_id, txn_date)`,
`transactions(user_id, merchant)`. Skipped for hackathon scale (single CSV, <1k rows).
