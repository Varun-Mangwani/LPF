# API_CONTRACT.md — Endpoint Specs

Base URL: `http://localhost:8000/api`
All list endpoints take `user_id` (int, default `1`) as a query param — this is
the only "multi-user" concept in scope (no auth, per PRD Non-Goals).

## Upload
`POST /api/upload/csv?user_id=1`
- multipart/form-data, field `file` = CSV with columns: `date, merchant, description, amount, type`
- Runs categorizer + recurring detector on insert.
- 200 → `{ "inserted": 42, "categorized_by_rule": 30, "categorized_by_llm": 12, "recurring_detected": 5 }`

## Transactions
`GET /api/transactions?user_id=1&category=Food&month=2026-09` → `TransactionOut[]`
`PATCH /api/transactions/{id}` body `{ "category": "Food", "is_essential": true }` → manual recategorize (`categorized_by="manual"`)

## Dashboard
`GET /api/dashboard/summary?user_id=1` →
```json
{
  "total_income": 85000,
  "total_expense": 62000,
  "by_category": [{"category": "Food", "amount": 6200, "essential": false}],
  "recurring_subscriptions": [{"merchant": "Netflix", "amount": 649, "category": "Subscription"}]
}
```

## Cash Flow
`GET /api/cashflow/projection?user_id=1&month=2026-09` →
```json
{ "start_balance": 20000, "days": [{"date":"2026-09-01","balance":20000}, ...], "month_end_balance": 31500 }
```

## Goals
`GET /api/goals?user_id=1` → `GoalOut[]`
`POST /api/goals?user_id=1` body `{ "name": "Emergency fund", "target_amount": 100000, "current_amount": 20000, "target_date": "2027-03-01" }`
  → returns `GoalOut` including computed `monthly_contribution_required`
`PUT /api/goals/{id}` → recompute + update
`DELETE /api/goals/{id}` → 204

## Liabilities
`GET /api/liabilities?user_id=1` → ranked list, `priority_rank=1` = pay first, each with `true_annual_cost` and a one-line `reasoning` string
`POST /api/liabilities?user_id=1` body `{ "name": "HDFC Credit Card", "type": "card", "balance": 45000, "interest_rate": 42, "min_payment": 2000 }`

## Alerts
`GET /api/alerts?user_id=1` → cached alerts
`POST /api/alerts/generate?user_id=1` → recompute deterministically, narrate via LLM, persist, return `AlertOut[]`

## Simulate (bonus)
`POST /api/simulate?user_id=1` body:
```json
{ "scenario": "new_emi", "params": { "amount": 8000, "start_date": "2026-10-01" } }
```
`scenario` ∈ `new_emi | rent_change | income_change`. Response:
```json
{
  "before": { "cashflow": {...}, "goals": [...] },
  "after":  { "cashflow": {...}, "goals": [...] },
  "narrative": "Adding a ₹8,000 EMI drops your month-end buffer by ₹8,000 and pushes your Emergency Fund goal from 5 to 6 months."
}
```

## Health
`GET /api/health` → `{ "status": "ok" }`
