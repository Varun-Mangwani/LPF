# AI_INTEGRATION.md — LLM Prompts & Rules

**Hard rule (see PRD §8): the LLM never computes a number.** All money math
lives in `engines/*.py` as pure functions. The LLM is used for exactly two
things:

1. **Categorization fallback** (`engines/categorizer.py`) — classify merchant
   strings that don't match the rules dict, into one of a fixed category enum.
2. **Narration** (`engines/alerts_engine.py`, `routers/simulate.py`) — turn
   already-computed numbers into a short plain-language explanation. The
   numbers are passed IN to the prompt; the LLM is told to only phrase them,
   never derive new ones.

`ai/llm_client.py` wraps the call and **must degrade gracefully with no API
key set** (offline demo mode) — categorization falls back to `"Uncategorized"`
and narration falls back to a deterministic string template. This keeps the
app fully demoable without network access.

## Categorization prompt (batched)

System:
> You are a transaction categorizer for an Indian personal finance app.
> Classify each merchant into exactly one category from this fixed list:
> Food, Groceries, Rent, EMI, Subscription, Utilities, Transport, Shopping,
> Health, Entertainment, Transfer, Salary, Investment, Other.
> Also say whether it is "essential" or "discretionary".
> Return ONLY valid JSON, no prose, no markdown fences.

User (template):
```json
{"merchants": ["Amazon Pay", "Zerodha", "Practo", "..."]}
```

Expected response shape:
```json
{"Amazon Pay": {"category": "Shopping", "essential": false},
 "Zerodha": {"category": "Investment", "essential": false}}
```

## Narration prompt (alerts / simulation)

System:
> You explain personal-finance numbers in one or two plain sentences for an
> Indian salaried user. You are given the exact numbers to use — do not
> invent, round dramatically, or add numbers not provided. No financial
> advice disclaimers, just the explanation.

User (template):
```
Alert type: overspend
Category: Food
This month spend: ₹8,400
Average of last 3 months: ₹6,000 (1.3x threshold = ₹7,800)
Write one sentence explaining why this triggered.
```

## Model
Default `claude-sonnet-4-6` via the Anthropic Messages API (swap-in GPT is a
one-line change in `llm_client.py` since prompts are model-agnostic). Read key
from `ANTHROPIC_API_KEY` env var — never hardcode it.
