@echo off
title Ledger - Local Development Launcher
echo ===================================================
echo   Ledger - Starting Backend and Frontend Locally
echo ===================================================
echo.

:: Ensure working directory is the script's root folder
cd /d "%~dp0"

:: 1. Launch FastAPI Backend
echo [1/2] Launching FastAPI Backend on port 8000...
start "Ledger Backend (FastAPI :8000)" cmd /k "title Ledger Backend && cd /d ""%~dp0backend"" && if exist .venv\Scripts\activate.bat (call .venv\Scripts\activate.bat) && python -m uvicorn main:app --reload --port 8000"

:: 2. Launch Vite Frontend
echo [2/2] Launching Vite Frontend on port 5173...
start "Ledger Frontend (Vite :5173)" cmd /k "title Ledger Frontend && cd /d ""%~dp0frontend"" && npm run dev"

echo.
echo ===================================================
echo   Both services are launching in separate windows:
echo     - Backend API:  http://localhost:8000
echo     - API Docs:     http://localhost:8000/docs
echo     - Frontend UI:  http://localhost:5173
echo.
echo   To stop a service, close its respective terminal
echo   window or press Ctrl+C inside it.
echo ===================================================
echo.

:: Wait 3 seconds and open the app in default browser
timeout /t 3 /nobreak >nul
start http://localhost:5173/

exit /b 0
